// Fichero: Punto2D.cpp

// Ficheros de cabecera
#include <iostream>
#include <cmath>

#include "punto2D.hpp"

// Espacios de nombres utilizados
using namespace std;

/*
 Definiciones de las funciones lectura y escritura de la clase Punto2D
*/

template < class T >  
void ed::Punto2D< T >::escribirPunto2D()
{
  cout << "(" << getX() << ", " << getY() << ")" << endl; 
}


template < class T >  
void ed::Punto2D< T >::leerPunto2D()
{
  T x, y;

  cout << "\n Lectura de las coordenadas de un punto: P(x,y) " << endl;

  cout << " Abscisa: x --> ";
  cin >> x;

  cout << " Ordenada: y --> ";
  cin >> y;

  // Se asignan los valores leídos a los atributos del punto   
  setX(x);
  setY(y);
}


