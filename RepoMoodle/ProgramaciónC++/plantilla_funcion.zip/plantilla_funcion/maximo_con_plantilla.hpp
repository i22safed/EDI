/*!
	\file  maximo_con_plantilla.hpp 
	\brief Fichero que define la función máximo mediante una plantilla (template)
*/

#ifndef _MAXIMO_CON_PLANTILLA_HPP_
#define _MAXIMO_CON_PLANTILLA_HPP_
/*!
	\fn     template <class T> T maximo( T a,  T b)
	\brief  Plantilla de una función que calcula el máximo de dos datos
	\note   Los datos deber de un tipo que permita la comparación ">="
	\param	a Primer dato que se va a comparar
	\param	b Segundo dato que se va a comparar
	\return	Máximo valor entre a y b
	\pre	Ninguna
	\post	El valor devuelto deber el máximo valor de a y b
*/
	template <class T>
	T maximo( T a,  T b)
	{
		if (a >= b)
		    return a;
		  return b;
	}
#endif // _MAXIMO_CON_PLANTILLA_HPP_
