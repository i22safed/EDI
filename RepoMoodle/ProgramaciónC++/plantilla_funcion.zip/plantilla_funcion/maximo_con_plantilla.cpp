/*!
	\file  maximo_con_plantilla.cpp 
	\brief Fichero que muestra el uso de una plantilla (template) para la función máximo.
*/

#include <iostream>
#include <string>

#include "maximo_con_plantilla.hpp"


using namespace std;

/*!
	\brief  Programa principal para mostrar el uso de la función máximo con plantilla
	\return Devuelve 0 si el funcionamiento ha sido correcto.
*/
int main()
{
  // Declaración de variables de diferentes tipos
  int i = 1, j= 2;
  double x = 9.5 , y = 6.7;
  string nombre1("Ana"), nombre2("Juan");

  // Comparación de datos de tipo entero
  cout << "El maximo de " << i << " y " << j << " es " << maximo(i, j) << endl;

  // Comparación de datos de tipo double
  cout << "El maximo de " << x << " y " << y << " es " << maximo(x, y) << endl;

  // Comparación de datos de tipo string
  cout << "El maximo de " << nombre1 << " y " << nombre2 ;
  cout << " es " << maximo(nombre1, nombre2) << endl;

  return 0;
}


